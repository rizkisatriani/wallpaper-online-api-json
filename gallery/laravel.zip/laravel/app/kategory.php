<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kategory extends Model
{
    //
}

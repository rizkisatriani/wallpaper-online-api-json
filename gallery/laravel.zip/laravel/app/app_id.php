<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class app_id extends Model
{
    //
}

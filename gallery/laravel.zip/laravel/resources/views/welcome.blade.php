
<html>

<head>
    <link href="{{ mix('css/app.css') }}" type="text/css" rel="stylesheet" />
    <script src="{{ mix('js/app.js') }}" type="text/javascript" defer></script>
</head>

<body  style="background-color: #3498db;">
     
    <div id="app">
    </div>
</body>

</html>
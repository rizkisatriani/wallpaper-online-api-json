<html lang="en" class="">
<head>
<meta charset="UTF-8">
<title>Laravel Simple Multiple File Upload Example Tutorial</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
</head>
<body>
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="card">
       <div class="card-header">Laravel Multiple Upload File Example</div>
 
         <div class="card-body">
            <?php if($message = Session::get('success')): ?>
 
                <div class="alert alert-success alert-block">
 
                    <button type="button" class="close" data-dismiss="alert">×</button>
 
                    <strong><?php echo e($message); ?></strong>
 
                </div>
            <?php endif; ?>
 
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
 
            <form action="<?php echo e(url('/save-multiple-file-upload')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="file" class="form-control-file" name="fileName[]" id="fileName" multiple="">
                   
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
 
         </div>
     </div>
  </div>
</div>
</html><?php /**PATH C:\wamp64\www\gallery\resources\views/create.blade.php ENDPATH**/ ?>
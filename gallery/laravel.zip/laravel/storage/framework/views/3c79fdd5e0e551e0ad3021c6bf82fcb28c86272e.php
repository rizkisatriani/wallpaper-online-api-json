
<html>

<head>
    <link href="<?php echo e(mix('css/app.css')); ?>" type="text/css" rel="stylesheet" />
    <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript" defer></script>
</head>

<body  style="background-color: #3498db;">
     
    <div id="app">
    </div>
</body>

</html><?php /**PATH C:\wamp64\www\gallery\resources\views/welcome.blade.php ENDPATH**/ ?>
<style> 
</style>
<template>

	<div class="wrapper">
        <!-- <app-header v-if="isAuth" />  -->
        <app-header /> 
    <div class='container'>
        <router-view></router-view>
    </div>
   <!--  <app-footer /> -->
    <!-- <app-footer v-if="isAuth" /> -->
    </div>

</template>
 
<script>
    import { mapState, mapGetters } from 'vuex'
    import Header from './Header.vue'
    import Footer from './Footer.vue'   
    export default {
        computed: {
            ...mapState(['token']),
            ...mapGetters(['isAuth'])

        },
        components: {
            'app-header': Header,
            'app-footer': Footer
        }
    }
</script>
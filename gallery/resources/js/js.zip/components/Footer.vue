<template>
<footer class="page-footer font-small bg-primary" >

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://mdbootstrap.com/"> MDBootstrap.com</a>
  </div>
  <!-- Copyright -->

</footer>
</template>

<script>
export default {
    
}
</script>